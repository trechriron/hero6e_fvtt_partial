'use strict'

/** import json files here for common data objects **/

export class Hero6eDataObjects {

}